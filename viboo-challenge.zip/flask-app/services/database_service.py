from influxdb_client import InfluxDBClient, Point
from datetime import datetime
from typing import Optional
import logging


class DatabaseService:
    """
    A service class for interacting with an InfluxDB instance, designed to handle temperature data.

    Attributes:
        bucket (str): The InfluxDB bucket where temperature data is stored.
        org (str): The organization in InfluxDB.
        db_client (InfluxDBClient): The InfluxDB client instance.
        logger (logging.Logger): Logger instance for logging errors or information.
    """

    def __init__(
        self, url: str, token: str, org: str, bucket: str, logger: logging.Logger
    ):
        """
        Initialize the DatabaseService with InfluxDB connection details.

        Args:
            url (str): The URL of the InfluxDB instance.
            token (str): The authentication token for the InfluxDB instance.
            org (str): The organization name in InfluxDB.
            bucket (str): The bucket name in InfluxDB.
            logger (logging.Logger): Logger instance for error handling and debugging.
        """
        self.bucket = bucket
        self.org = org
        self.db_client = InfluxDBClient(url=url, token=token, org=org)
        self.logger = logger

    def write_temperature(
        self, building_id: str, room_id: str, temperature: float, timestamp: datetime
    ) -> None:
        """
        Write a temperature record to the InfluxDB database.

        Args:
            building_id (str): The unique identifier of the building.
            room_id (str): The unique identifier of the room.
            temperature (float): The temperature value to record.
            timestamp (datetime): The timestamp when the temperature was recorded.

        Raises:
            Exception: If there is an error while writing to the database.
        """
        record = (
            Point("temperature-record")
            .tag("building_id", building_id)
            .tag("room_id", room_id)
            .field("temperature", temperature)
            .time(timestamp)
        )

        try:
            write_api = self.db_client.write_api()
            write_api.write(bucket=self.bucket, record=record)
        except Exception as e:
            self.logger.error(f"Error writing to InfluxDB: {e}")
            raise

    def get_average_temperature(
        self, building_id: str, room_id: str, duration: str = "15m"
    ) -> Optional[float]:
        """
        Query the average temperature for a specific building and room over a given duration.

        Args:
            building_id (str): The unique identifier of the building.
            room_id (str): The unique identifier of the room.
            duration (str): The time range for the query in a duration strings format (e.g., '15m'). Defaults to '15m'.

        Returns:
            Optional[float]: The average temperature if available, otherwise None.

        Raises:
            Exception: If there is an error while querying the database.
        """
        query = f"""
        from(bucket: "{self.bucket}")
          |> range(start: -{duration})
          |> filter(fn: (r) => r["_measurement"] == "temperature-record" and r["building_id"] == "{building_id}" and r["room_id"] == "{room_id}")
          |> mean()
        """

        try:
            query_api = self.db_client.query_api()
            result = query_api.query(org=self.org, query=query)

            # Extract the value from the query result
            for table in result:
                for record in table.records:
                    return record.get_value()
        except Exception as e:
            self.logger.error(f"Error querying InfluxDB: {e}")
            raise

        return None
