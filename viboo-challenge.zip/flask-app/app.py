from flask import Flask, request, jsonify, Response
from services.database_service import DatabaseService
from datetime import datetime
from http import HTTPStatus
from typing import Optional
import os

app = Flask(__name__)

# Configuration
INFLUXDB_URL: str = os.getenv("INFLUXDB_URL", "http://localhost:8086")
INFLUXDB_ORG: str = os.getenv("DOCKER_INFLUXDB_INIT_ORG", "default")
INFLUXDB_BUCKET: str = os.getenv("DOCKER_INFLUXDB_INIT_BUCKET", "default")
INFLUXDB_TOKEN: str = os.getenv("DOCKER_INFLUXDB_INIT_ADMIN_TOKEN", "default")

db_service = DatabaseService(
    url=INFLUXDB_URL,
    token=INFLUXDB_TOKEN,
    org=INFLUXDB_ORG,
    bucket=INFLUXDB_BUCKET,
    logger=app.logger,
)


@app.route(
    "/api/v1/buildings/<string:building_id>/rooms/<string:room_id>/temperatures",
    methods=["POST"],
)
def record_temperature(building_id: str, room_id: str) -> Response:
    """
    POST endpoint to record temperature data for a specific building and room.

    Args:
        building_id (str): The unique identifier of the building.
        room_id (str): The unique identifier of the room.

    JSON Body:
        {
            "temperature": float,  # Temperature in Celsius degrees.
            "recorded_at": str     # ISO 8601 formatted timestamp of the recording.
        }

    Returns:
        Response: JSON response indicating success or failure.
        - 200 OK: If the data is recorded successfully.
        - 400 Bad Request: If required fields are missing or invalid.
        - 500 Internal Server Error: If an error occurs while writing data.
    """
    data = request.json
    temperature: Optional[float] = data.get("temperature")
    timestamp: Optional[str] = data.get("recorded_at")

    if not temperature or not timestamp:
        return jsonify({"error": "Missing required fields"}), HTTPStatus.BAD_REQUEST

    try:
        db_service.write_temperature(
            building_id, room_id, float(temperature), datetime.fromisoformat(timestamp)
        )
        return jsonify({"status": "success"}), HTTPStatus.OK
    except Exception as e:
        app.logger.error(f"Error: {e}")
        return (
            jsonify({"error": "Failed to write data"}),
            HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@app.route(
    "/api/v1/buildings/<string:building_id>/rooms/<string:room_id>/temperatures/average",
    methods=["GET"],
)
def get_average_temperature(building_id: str, room_id: str) -> Response:
    """
    GET endpoint to retrieve the average temperature for a specific building and room over a given duration.

    Args:
        building_id (str): The unique identifier of the building.
        room_id (str): The unique identifier of the room.

    Query Parameters:
        duration (Optional[str]): The time duration for calculating the average temperature in the duration
                                  strings format (e.g., '15m'). Defaults to '15m' if not provided.

    Returns:
        Response: JSON response containing the average temperature or an error message.
        - 200 OK: If the average temperature is retrieved successfully.
        - 404 Not Found: If no data is found for the specified building and room.
        - 500 Internal Server Error: If an error occurs while querying data.
    """
    try:
        duration: str = request.args.get("duration", "15m")
        average_temperature: Optional[float] = db_service.get_average_temperature(
            building_id, room_id, duration
        )

        if average_temperature is None:
            return (
                jsonify({"error": "No data found for the specified building and room"}),
                HTTPStatus.NOT_FOUND,
            )

        response = jsonify(
            {
                "building": building_id,
                "room": room_id,
                "average_temperature": average_temperature,
                "duration": duration,
            }
        )
        return response, HTTPStatus.OK
    except Exception as e:
        app.logger.error(f"Error: {e}")
        return (
            jsonify({"error": "Failed to fetch data"}),
            HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@app.route("/api/v1/health", methods=["GET"])
def health_check() -> Response:
    """
    GET endpoint to check the health status of the application and database connection.

    Returns:
        Response: JSON response indicating the health status of the service.
        - 200 OK: If the service and database are healthy.
        - 500 Internal Server Error: If the service or database is unhealthy.
    """
    try:
        db_service.db_client.ping()
        return jsonify({"status": "healthy"}), HTTPStatus.OK
    except Exception as e:
        app.logger.error(f"Health check failed: {e}")
        return (
            jsonify({"status": "unhealthy", "error": str(e)}),
            HTTPStatus.INTERNAL_SERVER_ERROR,
        )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
